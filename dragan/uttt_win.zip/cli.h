#ifndef CLI_H__
#define CLI_H__

void cliPlayerMove(Board *b, int player, int *cY, int *cX);
void cliDrawBoard(Board *b);

#endif
